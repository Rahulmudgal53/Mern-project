
import React from 'react';
import Cart from './Cart';
function Header(props) {
    return (
        <div className='ui fixed menu'>
           <div className='ui container center'>
            <h2>E-SHOP</h2>
            <Cart/>
           </div>
        </div>
    );
}

export default Header;