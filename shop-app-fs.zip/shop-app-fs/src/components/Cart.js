import React from 'react';

function Cart(props) {
    return (
        <div>
            <i className='shop icon'></i>

        </div>
    );
}

export default Cart;